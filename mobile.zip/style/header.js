var mySwiper = new Swiper('.swiper-container',{
  pagination : '.swiper-pagination',
  paginationClickable :true,
  loop : true,
  loopAdditionalSlides : 0,
  autoplay : 2000,
  autoplayDisableOnInteraction : false,
})